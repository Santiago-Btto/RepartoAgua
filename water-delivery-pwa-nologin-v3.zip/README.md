# Reparto de Agua — SIN login (PWA + Firestore) — v3

Novedades:
- Muestra el cliente **apenas lo guardás** (onSnapshot en tiempo real).
- **Buscador** y **filtros** (día y estado).
- Campos de **stock**: 20 L, 12 L y sifones.
- **Editar** incluye los stock.
- Offline + sincronización automática.

Recuerda: reglas abiertas solo para pruebas. Luego te paso reglas más seguras.
