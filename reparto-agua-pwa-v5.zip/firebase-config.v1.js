export const firebaseConfig = {
  apiKey: "AIzaSyCJ3l5q1QNkz5aIKZNhhSgLoiriYdm7hoo",
  authDomain: "repartoagua-9fa53.firebaseapp.com",
  projectId: "repartoagua-9fa53",
  storageBucket: "repartoagua-9fa53.firebasestorage.app",
  messagingSenderId: "1074698000415",
  appId: "1:1074698000415:web:7d32aff99c37362fd01d2a",
  measurementId: "G-972M7DQDXD"
};
